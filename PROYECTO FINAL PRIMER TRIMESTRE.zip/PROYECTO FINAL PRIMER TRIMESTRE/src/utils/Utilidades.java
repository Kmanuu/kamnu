package utils;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Random;

public class Utilidades {
    public static Scanner teclado = new Scanner(System.in);




    //Corregir errores de numero entero
    public static int pideEntero(String msn) {
        int n = 0;
        boolean error = false;
        do {
            try {
                System.out.println(msn);
                n = teclado.nextInt();
                error = false;
            } catch (InputMismatchException e) {
                System.out.println("Valor no válido");
                error = true;
                teclado.nextLine();
            }
        } while (error);
        return n;
    }


    //pedir el nombre
    public static String pideString(String msn) {
        String cadena = null;
        cadena = teclado.nextLine();
        return cadena;
    }


//generaNumerosAleatorios para generar un numero aleatorio del 1-10 del array y coja la carta que represente ese numero

    public static int generaNumerosAleatorio(int max, int min){
        Random random = new Random();
        return random.nextInt((max-min) + 1) + min;
    }

















}
