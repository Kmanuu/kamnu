import controller.ControllerMain;
import model.Carta;
import model.Jugador;
import utils.Utilidades;
import view.VistaJugador;

public class Test {
    public static void main(String[] args) {
        VistaJugador.pideNombreJugador();
        Carta[] cartasJugador1 = new Carta[5];
        cartasJugador1 = Jugador.generaCarta(cartasJugador1);
        System.out.println("BATALLA DE CARTAS");
        int opcion;
        do {
            opcion = ControllerMain.muestraOpciones();
            ControllerMain.realizaOperaciones(opcion, cartasJugador1);
        } while (opcion != 3);

    }
}
