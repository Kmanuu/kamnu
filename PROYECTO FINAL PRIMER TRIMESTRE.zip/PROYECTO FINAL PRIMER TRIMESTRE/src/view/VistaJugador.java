package view;

import model.Jugador;
import utils.Utilidades;


public class VistaJugador {
    public static Jugador pideNombreJugador() {
        Jugador j = null;
        System.out.println("Introduce tu nombre:");
        String namePlayer = Utilidades.pideString("Nombre del jugador");
        return j;
    }

}












