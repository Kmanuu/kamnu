package controller;

import model.Carta;
import model.Jugador;
import utils.Utilidades;

public class ControllerMain {
    public static int muestraOpciones() {//Metodo que recoge la opcion y muestra las opciones
        int opcion = Utilidades.pideEntero("1. Mostrar cartas\n" +
                "2. Seleccionar carta\n" +
                "3. Salir");
        return opcion;
    }

    public static void realizaOperaciones(int opcion, Carta[] cartasJugador1) {//Switch con todas las opciones disponibles
        switch (opcion) {
            case 1:
                System.out.println("TUS CARTAS");
                Jugador.muestraCartas(cartasJugador1);
                break;
            case 2:

                break;
        }
    }
}