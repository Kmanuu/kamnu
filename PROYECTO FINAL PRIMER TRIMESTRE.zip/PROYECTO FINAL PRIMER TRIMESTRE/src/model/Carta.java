package model;

import utils.Utilidades;

public class Carta {
    private String nombre;
    private int ataque;
    private int defensa;
    private int vida;

    // Constructor por defecto (machaca al de java que da por defecto) para generar las cartas

    public Carta(Carta[] cartas) {
        this.nombre = listaCartas(Utilidades.generaNumerosAleatorio(10, 1));
        this.ataque = (Utilidades.generaNumerosAleatorio(100, 40));
        this.defensa =  (Utilidades.generaNumerosAleatorio(70, 30));
        this.vida =  (Utilidades.generaNumerosAleatorio(150, 80));
    }



    // Parte de los getters

    public String getNombre() {
        return nombre;
    }

    public int getAtaque() {
        return ataque;
    }

    public int getDefensa() {
        return defensa;
    }

    public int getVida() {
        return vida;
    }

    //------------------------------------------------------------------------------------------------

    // parte de los setters


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    //-------------------------------------------------------------------------------------------







    //definimos metodo toString() para poder mostrar los atributos  de la carta
    public String toString() {
        return "Nombre = " + this.nombre + " \n\tAtaque = " + this.ataque +
                "\n\tDefense = " + this.defensa + "\n\tVida = " + this.vida;





    }

    public  String listaCartas (int carta){

        switch (carta){
            case 1:
               this.nombre = "Dragon" ;
                break;
            case 2:
                this.nombre = "Mago";
                break;
            case 3:
                this.nombre = "Guerrero";
                break;
            case 4:
                this.nombre = "Arquero";
                break;
            case 5:
                this.nombre = "Golem";
                break;
            case 6:
                this.nombre = "Fénix";
                break;
            case 7:
                this.nombre = "Titán";
                break;
            case 8:
                this.nombre = "hechicero";
                break;
            case 9:
                this.nombre = "Bestia";
                break;
            case 10:
                this.nombre = "Caballero";
                break;

        }
    return nombre;
    }

    //Array que rellena los 5 elementos del con
    public static int[] rellenarArrayCartas(int[] cartas) {
        for (int i = 0; i < 5; i++) {
            cartas[i] = Utilidades.generaNumerosAleatorio(10, 1);
        }
        return cartas;
    }























}
