package model;


public class Jugador {
    private String nombreJugador;
    private Carta[] cartas = new Carta[5];
    private Carta[] cartasGeneradas = generaCarta(cartas);

    public Jugador() {

    }

    public Jugador(String nombreJugador, Carta[] cartas, Carta[] cartasGeneradas) {
        this.nombreJugador = nombreJugador;
        this.cartas = cartas;
        this.cartasGeneradas = cartasGeneradas;
    }

    public String getNombreJugador() {
        return nombreJugador;
    }

    public Carta[] getCartas() {
        return cartas;
    }

    public void setNombreJugador(String nombreJugador) {
        this.nombreJugador = nombreJugador;
    }

    public void setCartas(Carta[] cartas) {
        this.cartas = cartas;
    }

    public Carta[] getCartasGeneradas() {
        return cartasGeneradas;
    }

    public void setCartasGeneradas(Carta[] cartasGeneradas) {
        this.cartasGeneradas = cartasGeneradas;
    }

    public static Carta[] generaCarta(Carta[] cartas) {// Método para generar aleatoriamente 5 cartas y guardarlas en el array.
        Carta[] cartasGeneradas = new Carta[cartas.length];
        for (int i = 0; i < cartas.length; i++) {
            cartasGeneradas[i] = new Carta(cartas); // Crear una nueva carta
        }
        return cartasGeneradas;
    }

    public static void muestraCartas(Carta[] cartasGeneradas) {//Metodo que muestra las cartas disponibles
        for (int i = 0; i < cartasGeneradas.length; i++) {
            System.out.println("\nCarta " + (i + 1)); //Numero de carta
            System.out.println(cartasGeneradas[i]); // Mostrarla directamente
        }
    }

}
