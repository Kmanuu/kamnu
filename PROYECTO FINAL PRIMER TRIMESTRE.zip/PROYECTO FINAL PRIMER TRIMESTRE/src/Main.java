import controller.ControllerMain;
import model.Carta;
import model.Jugador;
import utils.Utilidades;
import view.VistaJugador;



public class Main {
    public static void main (String[] args){

    }
}
